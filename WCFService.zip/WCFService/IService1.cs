﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace WCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);
        [OperationContract]
        int InsertEmployee(Employee emp);
        // TODO: Add your service operations here
    }


    [DataContract]
    public class Employee
    {
        string name;
        string technology;
        int aWS;
        int totalExp;
        string Lbl;
        
        [DataMember]
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        [DataMember]
        public string Technology
        {
            get { return technology; }
            set { technology = value; }
        }
        [DataMember]
        public int AWS
        {
            get { return aWS; }
            set { aWS = value; }
        }
        [DataMember]
        public int TotalExp
        {
            get { return totalExp; }
            set { totalExp = value; }
        }
    }
   




    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
